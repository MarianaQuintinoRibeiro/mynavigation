package com.example.mynavigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
